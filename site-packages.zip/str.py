list=('liu','888','bin')
print(list*2)
dict={}
dict['one']=1
dict['two']=2
print(dict)
print(dict.values())
